/*
 * Hasan Y Ahmed
 * CSCI-C335
 * HW4
 * 11/08/17
 */
int string_length_c(char *c);
int string_length(char *c);
