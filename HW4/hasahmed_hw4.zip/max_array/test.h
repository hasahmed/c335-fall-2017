void test_max_array();
