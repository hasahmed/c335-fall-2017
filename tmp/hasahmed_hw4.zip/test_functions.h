void fib_test(void);
void gcd_test(void);
void abs_test(void);
