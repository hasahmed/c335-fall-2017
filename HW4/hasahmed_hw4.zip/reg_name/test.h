void test_reg_name();
