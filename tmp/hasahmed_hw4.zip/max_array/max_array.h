/*
 * Hasan Y Ahmed
 * CSCI-C335
 * HW4
 * 11/08/17
 */
unsigned int max_array_c(unsigned int *arr, int size);
unsigned int max_array(unsigned int *arr, int size);
