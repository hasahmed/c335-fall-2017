/*
 * Hasan Y Ahmed
 * CSCI-C335
 * HW4
 * 11/08/17
 */
unsigned int mult_by_5(unsigned int);        // Assembly function from abs.s
unsigned int mult_by_5_c(unsigned int);      // C function in abs_c.c
