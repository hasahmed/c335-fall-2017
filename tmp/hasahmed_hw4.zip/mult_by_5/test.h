void test_mult_by_5();
