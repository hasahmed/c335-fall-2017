/**
 * Hasan Y Ahmed
 * CSCI-C335
 * HW4 - mult_by_5: main.c
 * 11/08/17
 */
#include <stdio.h>
#include "test.h"
int main(void){
    test_string_length();
} 

/* main.c ends here */
