#include "mult_by_5.h"
unsigned int mult_by_5_c(unsigned int num) {
    return num * 5;
}
