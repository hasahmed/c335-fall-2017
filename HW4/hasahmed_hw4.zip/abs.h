/*
 * Hasan Y Ahmed
 * CSCI-C335
 * HW4
 * 11/08/17
 */
int abs_s(int);        // Assembly function from abs.s
int abs_c(int);      // C function in abs_c.c
