int abs_c(int num) {
  if (num>=0) return num;
  else return -num;
}
