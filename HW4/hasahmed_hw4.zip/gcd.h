int gcd(int,int);     // Assembly function from gcd.s
int gcd_c(int,int);   // C function from gcd_c.c
