/**
 * Hasan Y Ahmed
 * CSCI-C335
 * HW4
 * 11/08/17
 */
#include <stdio.h>
#include <stdint.h> 
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "test_functions.h"

int main(void){
    fib_test();
    abs_test();
    gcd_test();
    return 0;
} 

/* main.c ends here */
