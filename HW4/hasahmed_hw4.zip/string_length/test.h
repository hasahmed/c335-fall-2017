void test_string_length();
