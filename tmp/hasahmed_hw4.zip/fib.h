int fib(int);        // Assembly function from fib.s
int fib_c(int);      // C function from fib_c.c
